const fs = require("fs");
const path = require("path");
const { URL } = require("url");

const { renderLayout } = require("./templates/layout");
const { renderHome } = require("./templates/pages/home");
const { renderServicios } = require("./templates/pages/servicios");
const { renderProyectos } = require("./templates/pages/proyectos");
const { renderContacto } = require("./templates/pages/contacto");
const { renderAdminLogin, renderAdminDashboard } = require("./templates/pages/admin");
const { getMessages, addMessage, getProjects, getServices } = require("./lib/store");
const { checkPassword, createSessionToken, isAuthenticated } = require("./lib/auth");

const PUBLIC_DIR = __dirname;

const MIME_TYPES = {
  ".css": "text/css",
  ".js": "text/javascript",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".woff2": "font/woff2",
};

function send(res, status, body, headers = {}) {
  res.writeHead(status, { "Content-Type": "text/html; charset=utf-8", ...headers });
  res.end(body);
}

function sendJson(res, status, obj) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(obj));
}

// Sirve /public — solo se usa en local; en Vercel los estáticos los sirve la plataforma directamente.
function serveStatic(req, res, pathname) {
  const filePath = path.join(PUBLIC_DIR, pathname.replace("/", ""));
  if (!filePath.startsWith(PUBLIC_DIR)) {
    send(res, 403, "Prohibido");
    return true;
  }
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) return false;

  const ext = path.extname(filePath);
  const contentType = MIME_TYPES[ext] || "application/octet-stream";
  res.writeHead(200, { "Content-Type": contentType });
  fs.createReadStream(filePath).pipe(res);
  return true;
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    let size = 0;
    const MAX_SIZE = 1024 * 100; // 100kb
    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > MAX_SIZE) {
        reject(new Error("Cuerpo de la solicitud demasiado grande"));
        req.destroy();
        return;
      }
      data += chunk;
    });
    req.on("end", () => resolve(data));
    req.on("error", reject);
  });
}

function parseBody(req, rawBody) {
  const contentType = req.headers["content-type"] || "";
  if (contentType.includes("application/json")) {
    try {
      return JSON.parse(rawBody || "{}");
    } catch {
      return {};
    }
  }
  if (contentType.includes("application/x-www-form-urlencoded")) {
    const params = new URLSearchParams(rawBody);
    const out = {};
    for (const [key, value] of params.entries()) out[key] = value;
    return out;
  }
  return {};
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

async function handleRequest(req, res) {
  const parsedUrl = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  const pathname = decodeURIComponent(parsedUrl.pathname);

  try {
    // --- Archivos estáticos (solo relevante en local; Vercel los sirve aparte) ---
    if (pathname.startsWith("/css/") || pathname.startsWith("/js/") || pathname.startsWith("/img/")) {
      if (serveStatic(req, res, pathname)) return;
    }

    // --- Páginas públicas ---
    if (pathname === "/" && req.method === "GET") {
      const projects = getProjects().slice(0, 3);
      const html = renderLayout({
        title: "Heritage Modern Remodeling — Reformas de lujo en Madrid",
        description: "Reformas integrales, cocinas de diseño y baños spa con artesanía y calidad en cada detalle.",
        activeNav: "inicio",
        bodyHtml: renderHome(projects),
      });
      return send(res, 200, html);
    }

    if (pathname === "/servicios" && req.method === "GET") {
      const html = renderLayout({
        title: "Servicios — Heritage Modern Remodeling",
        description: "Reformas integrales, cocinas de diseño y baños spa.",
        activeNav: "servicios",
        bodyHtml: renderServicios(getServices()),
      });
      return send(res, 200, html);
    }

    if (pathname === "/proyectos" && req.method === "GET") {
      const html = renderLayout({
        title: "Proyectos — Heritage Modern Remodeling",
        description: "Explora nuestra galería de reformas recientes.",
        activeNav: "proyectos",
        bodyHtml: renderProyectos(getProjects()),
      });
      return send(res, 200, html);
    }

    if (pathname === "/contacto" && req.method === "GET") {
      const html = renderLayout({
        title: "Contacto — Heritage Modern Remodeling",
        description: "Solicita tu presupuesto gratuito para tu próxima reforma.",
        activeNav: "contacto",
        bodyHtml: renderContacto(),
      });
      return send(res, 200, html);
    }

    // --- API: formulario de contacto ---
    if (pathname === "/api/contacto" && req.method === "POST") {
      const raw = await readBody(req);
      const data = parseBody(req, raw);

      const nombre = (data.nombre || "").toString().trim().slice(0, 200);
      const email = (data.email || "").toString().trim().slice(0, 200);
      const telefono = (data.telefono || "").toString().trim().slice(0, 50);
      const tipo_reforma = (data.tipo_reforma || "").toString().trim().slice(0, 100);
      const mensaje = (data.mensaje || "").toString().trim().slice(0, 2000);

      if (!nombre || !email || !mensaje) {
        return sendJson(res, 400, { success: false, error: "Faltan campos obligatorios (nombre, email, mensaje)." });
      }
      if (!isValidEmail(email)) {
        return sendJson(res, 400, { success: false, error: "El email no parece válido." });
      }

      try {
        const entry = await addMessage({ nombre, email, telefono, tipo_reforma, mensaje });
        return sendJson(res, 201, { success: true, id: entry.id });
      } catch (e) {
        // En Vercel el sistema de archivos es de solo lectura fuera de /tmp:
        // el guardado persistente no funciona ahí sin una base de datos externa.
        console.error("No se pudo guardar el mensaje:", e.message);
        return sendJson(res, 200, {
          success: true,
          warning: "Recibido, pero el almacenamiento persistente no está disponible en este entorno.",
        });
      }
    }

    // --- Admin: login ---
    if (pathname === "/admin" && req.method === "GET") {
      if (isAuthenticated(req)) {
        res.writeHead(302, { Location: "/admin/dashboard" });
        return res.end();
      }
      return send(res, 200, renderAdminLogin(null));
    }

    if (pathname === "/admin/login" && req.method === "POST") {
      const raw = await readBody(req);
      const data = parseBody(req, raw);
      const password = (data.password || "").toString();

      if (checkPassword(password)) {
        const token = createSessionToken();
        res.writeHead(302, {
          Location: "/admin/dashboard",
          "Set-Cookie": `admin_session=${token}; HttpOnly; Path=/; Max-Age=28800; SameSite=Lax`,
        });
        return res.end();
      }
      return send(res, 401, renderAdminLogin("Contraseña incorrecta. Inténtalo de nuevo."));
    }

    if (pathname === "/admin/logout" && req.method === "POST") {
      res.writeHead(302, {
        Location: "/admin",
        "Set-Cookie": "admin_session=; HttpOnly; Path=/; Max-Age=0",
      });
      return res.end();
    }

    if (pathname === "/admin/dashboard" && req.method === "GET") {
      if (!isAuthenticated(req)) {
        res.writeHead(302, { Location: "/admin" });
        return res.end();
      }
      const html = renderAdminDashboard({ messages: await getMessages(), projects: getProjects() });
      return send(res, 200, html);
    }

    // --- 404 ---
    const notFoundHtml = renderLayout({
      title: "Página no encontrada — Heritage Modern",
      activeNav: "",
      bodyHtml: `
        <section class="pt-40 pb-32 px-gutter max-w-container-max mx-auto text-center">
          <h1 class="font-display-lg text-display-lg text-on-surface mb-6">404</h1>
          <p class="font-body-lg text-on-surface-variant mb-8">No hemos encontrado la página que buscas.</p>
          <a href="/" class="bg-primary-container text-on-primary-container px-8 py-4 rounded-DEFAULT font-label-caps text-label-caps hover:bg-primary hover:text-on-primary transition-colors inline-block">Volver al inicio</a>
        </section>`,
    });
    send(res, 404, notFoundHtml);
  } catch (err) {
    console.error(err);
    sendJson(res, 500, { success: false, error: "Error interno del servidor." });
  }
}

module.exports = { handleRequest };
