// server.js — arranque LOCAL (node server.js). En Vercel se usa api/index.js.
const http = require("http");
const { handleRequest } = require("./app");

const PORT = process.env.PORT || 3000;

const server = http.createServer(handleRequest);

server.listen(PORT, () => {
  console.log(`Heritage Modern corriendo en http://localhost:${PORT}`);
  console.log(`Panel de administración: http://localhost:${PORT}/admin (contraseña por defecto: cambia-esta-clave)`);
});
