// api/index.js — punto de entrada para Vercel (función serverless Node.js).
// vercel.json redirige TODAS las rutas hacia aquí, salvo lo que ya sirve
// Vercel directamente como estático (carpeta /public).
const { handleRequest } = require("../app");

module.exports = (req, res) => handleRequest(req, res);
