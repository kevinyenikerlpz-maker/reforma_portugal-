// public/js/main.js

// --- Menú móvil ---
(function () {
  const btn = document.getElementById("mobile-menu-btn");
  const menu = document.getElementById("mobile-menu");
  if (btn && menu) {
    btn.addEventListener("click", function () {
      menu.classList.toggle("hidden");
      menu.classList.toggle("flex");
    });
  }
})();

// --- Formulario de contacto ---
(function () {
  const form = document.getElementById("contact-form");
  if (!form) return;

  const messageBox = document.getElementById("form-message");
  const submitBtn = document.getElementById("form-submit-btn");

  form.addEventListener("submit", async function (e) {
    e.preventDefault();

    const data = {
      nombre: form.nombre.value.trim(),
      telefono: form.telefono.value.trim(),
      email: form.email.value.trim(),
      tipo_reforma: form.tipo_reforma.value,
      mensaje: form.mensaje.value.trim(),
    };

    if (!data.nombre || !data.email || !data.mensaje) {
      showMessage("Por favor, completa nombre, email y una breve descripción.", true);
      return;
    }

    submitBtn.classList.add("btn-loading");
    submitBtn.textContent = "Enviando...";

    try {
      const res = await fetch("/api/contacto", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const result = await res.json();

      if (res.ok && result.success) {
        showMessage("¡Gracias! Hemos recibido tu solicitud. Te contactaremos en menos de 24 horas.", false);
        form.reset();
      } else {
        showMessage(result.error || "Ha ocurrido un error. Inténtalo de nuevo.", true);
      }
    } catch (err) {
      showMessage("No se pudo enviar el formulario. Comprueba tu conexión e inténtalo de nuevo.", true);
    } finally {
      submitBtn.classList.remove("btn-loading");
      submitBtn.textContent = "Solicitar mi presupuesto gratuito";
    }
  });

  function showMessage(text, isError) {
    if (!messageBox) return;
    messageBox.textContent = text;
    messageBox.classList.remove("hidden");
    messageBox.classList.toggle("bg-error-container", isError);
    messageBox.classList.toggle("text-on-error-container", isError);
    messageBox.classList.toggle("bg-primary-fixed", !isError);
    messageBox.classList.toggle("text-on-primary-fixed", !isError);
  }
})();

// --- Filtro de proyectos ---
(function () {
  const filterBtns = document.querySelectorAll(".filter-btn");
  const cards = document.querySelectorAll("[data-category]");
  if (!filterBtns.length) return;

  filterBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      filterBtns.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");

      const category = btn.dataset.filter;
      cards.forEach((card) => {
        const show = category === "todos" || card.dataset.category === category;
        card.style.display = show ? "" : "none";
      });
    });
  });
})();
