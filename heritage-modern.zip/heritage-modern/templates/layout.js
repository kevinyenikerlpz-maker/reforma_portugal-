// templates/layout.js
// Layout base: head, header/nav y footer compartidos por todas las páginas.

function navLink(href, label, active) {
  const activeClasses = active
    ? "text-primary font-semibold"
    : "text-on-surface-variant dark:text-on-surface-variant hover:text-primary";
  return `<a class="${activeClasses} transition-colors font-label-caps text-label-caps hover:bg-surface-container-low/50 dark:hover:bg-surface-container-high/50 px-3 py-2 rounded-DEFAULT" href="${href}">${label}</a>`;
}

function renderHeader(activeNav) {
  return `
<header class="bg-surface/90 backdrop-blur-md dark:bg-surface-dim/90 sticky top-0 border-b border-on-surface/10 shadow-sm z-50 transition-all duration-300 ease-in-out">
  <div class="flex justify-between items-center w-full px-gutter max-w-container-max mx-auto h-20">
    <a class="font-display-lg text-headline-md text-on-surface tracking-tight" href="/" style="font-size: 28px;">Heritage Modern</a>
    <nav class="hidden md:flex space-x-2">
      ${navLink("/", "Inicio", activeNav === "inicio")}
      ${navLink("/servicios", "Servicios", activeNav === "servicios")}
      ${navLink("/proyectos", "Proyectos", activeNav === "proyectos")}
      ${navLink("/#proceso", "Proceso", false)}
      ${navLink("/#sobre-nosotros", "Nosotros", false)}
      ${navLink("/contacto", "Contacto", activeNav === "contacto")}
    </nav>
    <div class="flex items-center space-x-4">
      <a class="hidden md:flex items-center text-on-surface-variant hover:text-primary transition-colors" href="tel:+34900111222">
        <span class="material-symbols-outlined mr-2 text-[20px]">call</span>
        <span class="font-label-caps text-label-caps">+34 900 111 222</span>
      </a>
      <a class="bg-primary-container text-on-primary-container px-6 py-3 rounded-DEFAULT font-label-caps text-label-caps hover:bg-primary hover:text-on-primary transition-colors" href="/contacto">
        Solicitar Presupuesto
      </a>
      <button id="mobile-menu-btn" class="md:hidden text-on-surface" aria-label="Abrir menú">
        <span class="material-symbols-outlined">menu</span>
      </button>
    </div>
  </div>
  <div id="mobile-menu" class="hidden md:hidden flex-col bg-surface border-t border-on-surface/10 px-gutter py-4 space-y-2">
    <a class="block py-2 text-on-surface-variant hover:text-primary" href="/">Inicio</a>
    <a class="block py-2 text-on-surface-variant hover:text-primary" href="/servicios">Servicios</a>
    <a class="block py-2 text-on-surface-variant hover:text-primary" href="/proyectos">Proyectos</a>
    <a class="block py-2 text-on-surface-variant hover:text-primary" href="/#proceso">Proceso</a>
    <a class="block py-2 text-on-surface-variant hover:text-primary" href="/#sobre-nosotros">Nosotros</a>
    <a class="block py-2 text-on-surface-variant hover:text-primary" href="/contacto">Contacto</a>
  </div>
</header>`;
}

function renderFooter() {
  const year = new Date().getFullYear();
  return `
<footer class="bg-surface-container dark:bg-inverse-surface border-t border-on-surface/10 transition-opacity duration-200">
  <div class="grid grid-cols-1 md:grid-cols-4 gap-12 px-gutter py-20 max-w-container-max mx-auto">
    <div class="col-span-1">
      <a class="font-display-lg text-headline-md text-on-surface dark:text-inverse-on-surface mb-4 block" href="/" style="font-size: 24px;">Heritage Modern</a>
      <p class="font-body-md text-body-md text-on-surface-variant dark:text-on-tertiary-fixed-variant mb-6">
        Creando espacios extraordinarios que perduran en el tiempo. Artesanía y diseño unidos.
      </p>
    </div>
    <div class="col-span-1">
      <h4 class="font-label-caps text-label-caps text-primary dark:text-primary-fixed-dim mb-6">SERVICIOS</h4>
      <ul class="space-y-4">
        <li><a class="font-body-md text-on-surface-variant hover:text-primary hover:underline decoration-primary/30 underline-offset-4 transition-colors" href="/servicios">Reformas Integrales</a></li>
        <li><a class="font-body-md text-on-surface-variant hover:text-primary hover:underline decoration-primary/30 underline-offset-4 transition-colors" href="/servicios">Cocinas de Diseño</a></li>
        <li><a class="font-body-md text-on-surface-variant hover:text-primary hover:underline decoration-primary/30 underline-offset-4 transition-colors" href="/servicios">Baños Spa</a></li>
      </ul>
    </div>
    <div class="col-span-1">
      <h4 class="font-label-caps text-label-caps text-primary dark:text-primary-fixed-dim mb-6">ENLACES</h4>
      <ul class="space-y-4">
        <li><a class="font-body-md text-on-surface-variant hover:text-primary hover:underline decoration-primary/30 underline-offset-4 transition-colors" href="/proyectos">Proyectos</a></li>
        <li><a class="font-body-md text-on-surface-variant hover:text-primary hover:underline decoration-primary/30 underline-offset-4 transition-colors" href="/contacto">Contacto</a></li>
        <li><a class="font-body-md text-on-surface-variant hover:text-primary hover:underline decoration-primary/30 underline-offset-4 transition-colors" href="/admin">Acceso administración</a></li>
      </ul>
    </div>
    <div class="col-span-1">
      <h4 class="font-label-caps text-label-caps text-primary dark:text-primary-fixed-dim mb-6">CONTACTO</h4>
      <ul class="space-y-4">
        <li class="font-body-md text-on-surface-variant">+34 900 111 222</li>
        <li class="font-body-md text-on-surface-variant">hola@heritagemodern.es</li>
        <li class="font-body-md text-on-surface-variant">Calle de la Artesanía, 12, Madrid</li>
      </ul>
    </div>
  </div>
  <div class="px-gutter pb-8 max-w-container-max mx-auto text-center md:text-left border-t border-on-surface/5 pt-8">
    <p class="font-body-md text-sm text-on-surface-variant/70">© ${year} Heritage Modern Remodeling. Todos los derechos reservados.</p>
  </div>
</footer>`;
}

const TAILWIND_CONFIG = `
tailwind.config = {
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        "surface-container-lowest": "#ffffff",
        "on-surface": "#1b1c19",
        "on-background": "#1b1c19",
        "error": "#ba1a1a",
        "outline": "#7f7667",
        "inverse-primary": "#e9c176",
        "on-tertiary-fixed": "#1b1c1b",
        "secondary-fixed": "#ffdbc9",
        "inverse-on-surface": "#f2f1ec",
        "on-primary": "#ffffff",
        "surface": "#fbf9f4",
        "secondary-fixed-dim": "#ffb68c",
        "on-secondary": "#ffffff",
        "on-primary-container": "#4e3700",
        "on-surface-variant": "#4e4639",
        "on-tertiary-fixed-variant": "#474745",
        "error-container": "#ffdad6",
        "primary-fixed": "#ffdea5",
        "surface-container-highest": "#e4e2dd",
        "surface-bright": "#fbf9f4",
        "on-secondary-container": "#783603",
        "secondary-container": "#ffa26a",
        "surface-variant": "#e4e2dd",
        "surface-dim": "#dbdad5",
        "on-secondary-fixed": "#321200",
        "secondary": "#934b19",
        "on-primary-fixed": "#261900",
        "primary-fixed-dim": "#e9c176",
        "primary": "#775a19",
        "on-tertiary-container": "#3b3b3a",
        "inverse-surface": "#30312e",
        "on-tertiary": "#ffffff",
        "tertiary-container": "#a7a5a3",
        "on-error": "#ffffff",
        "on-error-container": "#93000a",
        "background": "#fbf9f4",
        "tertiary-fixed-dim": "#c8c6c4",
        "surface-container-low": "#f5f3ee",
        "surface-tint": "#775a19",
        "primary-container": "#c5a059",
        "surface-container": "#f0eee9",
        "surface-container-high": "#eae8e3",
        "on-secondary-fixed-variant": "#753401",
        "outline-variant": "#d1c5b4",
        "tertiary": "#5f5e5d",
        "tertiary-fixed": "#e4e2e0",
        "on-primary-fixed-variant": "#5d4201"
      },
      borderRadius: { DEFAULT: "0.125rem", lg: "0.25rem", xl: "0.5rem", full: "0.75rem" },
      spacing: { "container-max": "1280px", gutter: "24px", base: "8px", "section-gap": "120px", "margin-mobile": "20px" },
      fontFamily: {
        "headline-lg": ["EB Garamond"], "display-lg": ["EB Garamond"], "body-lg": ["Hanken Grotesk"],
        "display-lg-mobile": ["EB Garamond"], "body-md": ["Hanken Grotesk"], "label-caps": ["Hanken Grotesk"],
        "headline-md": ["EB Garamond"]
      },
      fontSize: {
        "headline-lg": ["48px", { lineHeight: "1.2", fontWeight: "500" }],
        "display-lg": ["64px", { lineHeight: "1.1", letterSpacing: "-0.02em", fontWeight: "500" }],
        "body-lg": ["18px", { lineHeight: "1.6", fontWeight: "400" }],
        "display-lg-mobile": ["40px", { lineHeight: "1.2", fontWeight: "500" }],
        "body-md": ["16px", { lineHeight: "1.6", fontWeight: "400" }],
        "label-caps": ["12px", { lineHeight: "1.0", letterSpacing: "0.1em", fontWeight: "600" }],
        "headline-md": ["32px", { lineHeight: "1.3", fontWeight: "500" }]
      }
    }
  }
};`;

function renderLayout({ title, description = "", activeNav = "", bodyHtml = "", extraHead = "" }) {
  return `<!DOCTYPE html>
<html class="light" lang="es">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>${title}</title>
<meta name="description" content="${description}"/>
<script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<link href="https://fonts.googleapis.com/css2?family=EB+Garamond:wght@400;500;600;700&family=Hanken+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
<script id="tailwind-config">${TAILWIND_CONFIG}</script>
<link rel="stylesheet" href="/css/style.css"/>
${extraHead}
</head>
<body class="bg-background text-on-background font-body-md antialiased selection:bg-primary-container selection:text-on-primary-container">
${renderHeader(activeNav)}
${bodyHtml}
${renderFooter()}
<script src="/js/main.js"></script>
</body>
</html>`;
}

module.exports = { renderLayout };
