function renderHome(featuredProjects) {
  const projectCards = featuredProjects
    .map(
      (p) => `
    <a href="/proyectos#${p.id}" class="group relative rounded-DEFAULT overflow-hidden aspect-[4/3] cursor-pointer block">
      <img alt="${p.title}" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" src="${p.image}"/>
      <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80"></div>
      <div class="absolute bottom-6 left-6 right-6">
        <span class="inline-block bg-primary-container/90 text-on-primary-container px-2 py-1 rounded text-xs font-label-caps mb-3">${p.category.toUpperCase()}</span>
        <h3 class="font-headline-md text-white text-2xl">${p.title}</h3>
      </div>
    </a>`
    )
    .join("\n");

  return `
<!-- HERO -->
<section class="relative pt-32 pb-24 px-gutter max-w-container-max mx-auto grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
  <div class="col-span-12 md:col-span-6 z-10 pr-0 md:pr-12">
    <h1 class="font-display-lg text-display-lg text-on-surface mb-6">Transformamos tu hogar con maestría</h1>
    <p class="font-body-lg text-body-lg text-on-surface-variant mb-10 max-w-lg">
      Reformas integrales de lujo que combinan proporciones clásicas con minimalismo contemporáneo. Artesanía y calidad en cada detalle de tu nuevo espacio.
    </p>
    <div class="flex flex-col sm:flex-row items-start sm:items-center gap-6">
      <a class="bg-primary-container text-on-primary-container px-8 py-4 rounded-DEFAULT font-label-caps text-label-caps hover:bg-primary hover:text-on-primary transition-colors text-center w-full sm:w-auto" href="/contacto">
        Solicitar Presupuesto
      </a>
      <div class="flex items-center gap-3">
        <div class="flex text-primary-container">
          <span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">star</span>
          <span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">star</span>
          <span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">star</span>
          <span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">star</span>
          <span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">star_half</span>
        </div>
        <span class="font-body-md text-on-surface-variant text-sm">4.9/5 en Google · +200 reformas</span>
      </div>
    </div>
  </div>
  <div class="col-span-12 md:col-span-6 relative mt-12 md:mt-0">
    <div class="relative w-full aspect-[4/5] md:aspect-[3/4] p-1 bg-surface-container-low border border-outline-variant/30 rounded-DEFAULT overflow-hidden">
      <div class="bg-cover bg-center w-full h-full rounded-DEFAULT shadow-sm" style="background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuCrvo3j95tdAAEo45e2H9J1OUXmXxl4elRxqX9E2e7gRZjZRLrFsC2DyagbuN5uL1DlyFiERmJ2V_psrWuPMuorJQdq3JF2vH-GmDQ6nYJkSYJd9skROlgZ8mDkgkCn3Of1DjmqKn5ArlLX0it7wRC52EUMMAOeaXZh-LhIXIIGhuMtxLhWI3c2NY2P7CQP6Z6UqeByQurbuGITUIDGqPcU3kxaL4UC0xHZk-yKxxBZipnPuHxRJbex1Q')"></div>
    </div>
    <div class="absolute -bottom-6 -left-6 w-32 h-32 bg-primary-fixed/20 rounded-full blur-2xl -z-10"></div>
  </div>
</section>

<!-- TRUST BAR -->
<section class="py-12 bg-surface-container-low border-y border-outline-variant/20">
  <div class="max-w-container-max mx-auto px-gutter">
    <div class="flex flex-wrap justify-center gap-12 md:gap-24 opacity-70">
      <div class="flex items-center gap-3">
        <span class="material-symbols-outlined text-primary text-[28px]">verified</span>
        <span class="font-label-caps text-label-caps text-on-surface-variant">Seguro a Todo Riesgo</span>
      </div>
      <div class="flex items-center gap-3">
        <span class="material-symbols-outlined text-primary text-[28px]">workspace_premium</span>
        <span class="font-label-caps text-label-caps text-on-surface-variant">Garantía de 5 Años</span>
      </div>
      <div class="flex items-center gap-3">
        <span class="material-symbols-outlined text-primary text-[28px]">handyman</span>
        <span class="font-label-caps text-label-caps text-on-surface-variant">Artesanos Certificados</span>
      </div>
    </div>
  </div>
</section>

<!-- SERVICIOS -->
<section class="py-24 px-gutter max-w-container-max mx-auto" id="servicios">
  <div class="text-center mb-16">
    <h2 class="font-headline-lg text-headline-lg text-on-surface mb-4">Nuestros Servicios</h2>
    <p class="font-body-lg text-on-surface-variant max-w-2xl mx-auto">Especialistas en transformar espacios con materiales de primera calidad y acabados impecables.</p>
  </div>
  <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
    <div class="bg-surface-container-low p-8 rounded-DEFAULT border border-outline-variant/30 hover:border-primary/50 transition-colors">
      <span class="material-symbols-outlined text-primary-container text-4xl mb-6">home_work</span>
      <h3 class="font-headline-md text-headline-md text-on-surface mb-4">Reformas Integrales</h3>
      <p class="font-body-md text-on-surface-variant">Transformamos viviendas completas, optimizando la distribución y renovando todas las instalaciones para un hogar moderno y funcional.</p>
    </div>
    <div class="bg-surface-container-low p-8 rounded-DEFAULT border border-outline-variant/30 hover:border-primary/50 transition-colors">
      <span class="material-symbols-outlined text-primary-container text-4xl mb-6">countertops</span>
      <h3 class="font-headline-md text-headline-md text-on-surface mb-4">Cocinas de Diseño</h3>
      <p class="font-body-md text-on-surface-variant">Creamos el corazón de tu hogar con mobiliario a medida, encimeras premium y electrodomésticos integrados de última generación.</p>
    </div>
    <div class="bg-surface-container-low p-8 rounded-DEFAULT border border-outline-variant/30 hover:border-primary/50 transition-colors">
      <span class="material-symbols-outlined text-primary-container text-4xl mb-6">bathtub</span>
      <h3 class="font-headline-md text-headline-md text-on-surface mb-4">Baños Spa</h3>
      <p class="font-body-md text-on-surface-variant">Diseñamos oasis de relajación con grifería empotrada, platos de ducha a ras de suelo y revestimientos porcelánicos de gran formato.</p>
    </div>
  </div>
  <div class="text-center mt-12">
    <a href="/servicios" class="font-label-caps text-primary hover:text-primary-container transition-colors inline-flex items-center gap-2">
      VER TODOS LOS SERVICIOS <span class="material-symbols-outlined">arrow_forward</span>
    </a>
  </div>
</section>

<!-- ANTES Y DESPUÉS -->
<section class="py-24 bg-surface-container-low px-gutter border-y border-outline-variant/20">
  <div class="max-w-container-max mx-auto">
    <div class="text-center mb-16">
      <h2 class="font-headline-lg text-headline-lg text-on-surface mb-4">La Transformación</h2>
      <p class="font-body-lg text-on-surface-variant max-w-2xl mx-auto">El poder de un buen diseño y ejecución. Descubre cómo renovamos por completo estos espacios.</p>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-12">
      <div>
        <h3 class="font-headline-md text-headline-md text-on-surface mb-6">Proyecto Salamanca</h3>
        <div class="flex flex-col gap-4">
          <div class="relative aspect-video rounded-DEFAULT overflow-hidden border border-outline-variant/30">
            <img alt="Cocina Antes" class="w-full h-full object-cover filter grayscale opacity-80" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDrc4mNmDUdYCoU0ISF65LWIPhTJuXrHeKI3fKMHaO1AA46X9eXjmlteBVd9KZ0VOMxldODIocgHI2usrp_r2aj0s2nE-xWV1gbaD6yCmhO97sMPKxcsAHd2GVplrwb9cHLYmmmwvJJIvSbAV6vTnN5vIj-AqP9h61wRjbNW7cEsbVT51TcXV3MhvtSqiaMbAEQkeLHtQd_H7ZbTdPDqWp2aOb2YQKNIEFlFxMlf81YT309njyGhSirEg"/>
            <div class="absolute top-4 left-4 bg-surface/90 px-3 py-1 rounded font-label-caps text-xs">ANTES</div>
          </div>
          <div class="relative aspect-video rounded-DEFAULT overflow-hidden border border-outline-variant/30 shadow-md">
            <img alt="Cocina Después" class="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBbkHLror5fw0f2qrzCcCfX9qHALOYsligj2Ab9VnG4WYZlfDv5gyw4uztZ4XpeImr2uGTPgaAgPbRzvunwNZrM3zU8MqHT4P2NY0SzaWihATsi_iPcrkzyi9D18zYC1aL1AKTCO_uwL40Hh-PnbjDhpgvA_HhOt02Zwp2YjINL-qJ-EfANhybtpI3EMiMqko2rQFGfMB4LA1Zkdt8x8i_bDIhQ05BguIVlRC9_X3mmntypcojZpUrTKQ"/>
            <div class="absolute top-4 left-4 bg-primary-container text-on-primary-container px-3 py-1 rounded font-label-caps text-xs">DESPUÉS</div>
          </div>
        </div>
      </div>
      <div>
        <h3 class="font-headline-md text-headline-md text-on-surface mb-6">Ático Chamberí</h3>
        <div class="flex flex-col gap-4">
          <div class="relative aspect-video rounded-DEFAULT overflow-hidden border border-outline-variant/30">
            <img alt="Baño Antes" class="w-full h-full object-cover filter grayscale opacity-80" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBOfAsSHlFGRf3dN-Lcgj-gwAd5ihx0bfZ9s_gTEM642b7iRuSzTJtigH61vTWj1KMVrnNbdy_nIfSKJ0w7UGpqa_rry60NUOM9F73OgXrL4KnK3V57_m6lPM7RZwWH3K4AtyFmqWZw23WSQGEbigLj0OopI9BBKt1SAKede4wmVb7LuDFN_pZVofamFzuGzQ2K6pe5B8w0uDI5oaxHv-dxQ7jk4rLhJUH8Q2EcyK5tm495lglvhXvTNQ"/>
            <div class="absolute top-4 left-4 bg-surface/90 px-3 py-1 rounded font-label-caps text-xs">ANTES</div>
          </div>
          <div class="relative aspect-video rounded-DEFAULT overflow-hidden border border-outline-variant/30 shadow-md">
            <img alt="Baño Después" class="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCzw_-fSvC35duHGmeDw8rgkxuqh3nmd6Ts1Lin8IBG6BRgKecSRmgp46plYpqHAPllaYaOlK2lCKq7kBWH8PH6uNwbGSaZrhJKLNmI7nBvcaspr_fSeY2TfMt1pb79AVw9PWpjnwNqLncEbXc2FvEyjqZGgKHg1Nk-622oU70qdO5TIu_fVeHSNgt1TkIxA0Wqf0BWdd0H3qFeISvXCnkIWd5ryzLpdNXPIq6gwoqC_1LRine63aSLAw"/>
            <div class="absolute top-4 left-4 bg-primary-container text-on-primary-container px-3 py-1 rounded font-label-caps text-xs">DESPUÉS</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- PROCESO -->
<section class="py-24 px-gutter max-w-container-max mx-auto" id="proceso">
  <div class="text-center mb-16">
    <h2 class="font-headline-lg text-headline-lg text-on-surface mb-4">Nuestro Proceso</h2>
    <p class="font-body-lg text-on-surface-variant max-w-2xl mx-auto">Un método estructurado para garantizar resultados excelentes y tranquilidad durante toda la obra.</p>
  </div>
  <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
    <div class="text-center">
      <div class="w-20 h-20 bg-surface-container-low rounded-full flex items-center justify-center mx-auto mb-6 border border-outline-variant/30 text-primary-container text-3xl">
        <span class="material-symbols-outlined">forum</span>
      </div>
      <h3 class="font-headline-md text-xl text-on-surface mb-3">1. Consulta Gratuita</h3>
      <p class="font-body-md text-on-surface-variant">Visitamos tu espacio, escuchamos tus ideas y tomamos medidas iniciales sin compromiso.</p>
    </div>
    <div class="text-center">
      <div class="w-20 h-20 bg-surface-container-low rounded-full flex items-center justify-center mx-auto mb-6 border border-outline-variant/30 text-primary-container text-3xl">
        <span class="material-symbols-outlined">design_services</span>
      </div>
      <h3 class="font-headline-md text-xl text-on-surface mb-3">2. Diseño y Presupuesto</h3>
      <p class="font-body-md text-on-surface-variant">Presentamos propuestas 3D, selección de materiales y un presupuesto detallado y cerrado.</p>
    </div>
    <div class="text-center">
      <div class="w-20 h-20 bg-surface-container-low rounded-full flex items-center justify-center mx-auto mb-6 border border-outline-variant/30 text-primary-container text-3xl">
        <span class="material-symbols-outlined">construction</span>
      </div>
      <h3 class="font-headline-md text-xl text-on-surface mb-3">3. Ejecución</h3>
      <p class="font-body-md text-on-surface-variant">Nuestro equipo de artesanos comienza la obra bajo la supervisión constante de un jefe de proyecto.</p>
    </div>
    <div class="text-center">
      <div class="w-20 h-20 bg-surface-container-low rounded-full flex items-center justify-center mx-auto mb-6 border border-outline-variant/30 text-primary-container text-3xl">
        <span class="material-symbols-outlined">task_alt</span>
      </div>
      <h3 class="font-headline-md text-xl text-on-surface mb-3">4. Entrega y Garantía</h3>
      <p class="font-body-md text-on-surface-variant">Limpieza final, revisión exhaustiva y entrega de llaves con nuestra garantía de 5 años.</p>
    </div>
  </div>
</section>

<!-- PROYECTOS DESTACADOS -->
<section class="py-24 bg-surface-container-lowest px-gutter border-y border-outline-variant/20">
  <div class="max-w-container-max mx-auto">
    <div class="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
      <div>
        <h2 class="font-headline-lg text-headline-lg text-on-surface mb-4">Proyectos Recientes</h2>
        <p class="font-body-lg text-on-surface-variant max-w-xl">Explora nuestra selección de reformas recientes y encuentra inspiración para tu próximo proyecto.</p>
      </div>
      <a class="font-label-caps text-primary hover:text-primary-container transition-colors flex items-center gap-2" href="/proyectos">
        VER TODOS LOS PROYECTOS <span class="material-symbols-outlined">arrow_forward</span>
      </a>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      ${projectCards}
    </div>
  </div>
</section>

<!-- TESTIMONIOS -->
<section class="py-24 px-gutter max-w-container-max mx-auto">
  <div class="text-center mb-16">
    <h2 class="font-headline-lg text-headline-lg text-on-surface mb-4">Lo que dicen nuestros clientes</h2>
  </div>
  <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
    <div class="bg-surface-container-low p-8 rounded-DEFAULT border border-outline-variant/30">
      <div class="flex text-primary-container mb-4">
        <span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">star</span><span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">star</span><span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">star</span><span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">star</span><span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">star</span>
      </div>
      <p class="font-body-md text-on-surface-variant italic mb-6">"El nivel de detalle y profesionalidad superó nuestras expectativas. Cumplieron los plazos y el presupuesto al céntimo. Nuestra nueva cocina es el centro de atención."</p>
      <div class="flex items-center gap-4">
        <img alt="María G." class="w-12 h-12 rounded-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAsIHHHMtHlSLPQ-xbpAAIgzoB2Pm8b5bUPFpZ9sQwHoZMFX69ajh8Jex_Nh4UsziDFoYgB5j2XeGqQ3f9cSKy72vxr0MCbFoAvKUyPyGXyHay8I_nT-9RY7AGlHx0rJytb6TqcBYlxIcAcvOKtKEVC2kS66sxcXF3PzGRAlTLi0fpf-qwJUhim3zAo0lvgKBP9dk48kekieuQIC2A4bSLvB6c_yvvbpt8CuKM8NKQ96sgb6M0Wg7ORow"/>
        <div><p class="font-label-caps text-on-surface font-semibold">María Gómez</p><p class="text-sm text-on-surface-variant">Reforma Cocina</p></div>
      </div>
    </div>
    <div class="bg-surface-container-low p-8 rounded-DEFAULT border border-outline-variant/30">
      <div class="flex text-primary-container mb-4">
        <span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">star</span><span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">star</span><span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">star</span><span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">star</span><span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">star</span>
      </div>
      <p class="font-body-md text-on-surface-variant italic mb-6">"Transformaron nuestro antiguo piso en un espacio luminoso y moderno conservando las molduras originales. Un trabajo impecable de principio a fin."</p>
      <div class="flex items-center gap-4">
        <img alt="Carlos M." class="w-12 h-12 rounded-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDLMTLJVriIbKyeOxyC01W553-yRYR1NDTIpsh0T5LUQVgGz2pvEONdcuKh31rSi7LRrpKGafyh3cGiA8XQEz4_8IHzgMDAzo8QJL0yyhkmCGjA_fHoMlXNwRJWE-ysWMD2bGbFal2B0VGNpHXGSBH7OUMphIKbuzjhvAa4j3WcBPvmb5VaiqcvbXn1iEMWCAa6igs5jNrSgdl7azXOJy2XW5rrpZDKfYC4M9biz4Mu7iH_GI_DFzmZ8A"/>
        <div><p class="font-label-caps text-on-surface font-semibold">Carlos Martínez</p><p class="text-sm text-on-surface-variant">Reforma Integral</p></div>
      </div>
    </div>
    <div class="bg-surface-container-low p-8 rounded-DEFAULT border border-outline-variant/30">
      <div class="flex text-primary-container mb-4">
        <span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">star</span><span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">star</span><span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">star</span><span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">star</span><span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">star_half</span>
      </div>
      <p class="font-body-md text-on-surface-variant italic mb-6">"Muy recomendables. Nos asesoraron genialmente con los materiales y el equipo de obra fue muy limpio y respetuoso con los vecinos."</p>
      <div class="flex items-center gap-4">
        <img alt="Laura V." class="w-12 h-12 rounded-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCkoob6YfmlvzqwNPpL3juJRnrrMM5k6lg27oML8-52PpSoE7U_WglceDXnmU9kV9efYaL4iW__LVOVeGCyUPpx44F4RrYkZ_l4sr--D9EPjMM-Ca8CSkngf94-aBDUNMRXMQjTAYvjgunDin6h43OWfHfGXBudDUudRd9ZdCRC7U_Rct-9tlnMIMazYYkg9iElEW0mHyCuZIBMq7XqGmjvRgiE6VmcyQTZFGL9DQHdQCDYuiu9iEI9CQ"/>
        <div><p class="font-label-caps text-on-surface font-semibold">Laura Vargas</p><p class="text-sm text-on-surface-variant">Reforma Baños</p></div>
      </div>
    </div>
  </div>
</section>

<!-- SOBRE NOSOTROS -->
<section class="py-24 bg-surface-container-low px-gutter border-y border-outline-variant/20" id="sobre-nosotros">
  <div class="max-w-container-max mx-auto grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
    <div class="order-2 md:order-1">
      <h2 class="font-headline-lg text-headline-lg text-on-surface mb-6">Artesanía y Vanguardia</h2>
      <p class="font-body-lg text-on-surface-variant mb-6">Fundada hace más de 15 años, Heritage Modern nació con la visión de elevar el estándar de las reformas residenciales en la ciudad. Creemos que cada hogar tiene un alma y nuestro trabajo es realzarla.</p>
      <p class="font-body-lg text-on-surface-variant mb-8">Combinamos técnicas artesanales tradicionales con las últimas innovaciones en materiales y domótica para crear espacios que no solo son estéticamente bellos, sino profundamente funcionales y duraderos.</p>
      <div class="grid grid-cols-2 gap-6 border-t border-outline-variant/30 pt-8">
        <div><p class="font-display-lg text-primary-container text-4xl mb-2">+15</p><p class="font-label-caps text-on-surface-variant">AÑOS DE EXPERIENCIA</p></div>
        <div><p class="font-display-lg text-primary-container text-4xl mb-2">+200</p><p class="font-label-caps text-on-surface-variant">PROYECTOS ENTREGADOS</p></div>
      </div>
    </div>
    <div class="order-1 md:order-2 relative">
      <img alt="Equipo Heritage Modern" class="w-full rounded-DEFAULT shadow-lg" src="https://lh3.googleusercontent.com/aida-public/AB6AXuD6sUNiIwTKWZuHEJiOw7CzBp9LO0qyEreFjdcZnrRct7u3v2hRAQNgdCGDptrfkuBicPhDoNYTnL73kI1PeAhejzwxBLt6_Aghbc0MUYo00FuMv6ndZ0pI1hb8pbaMuP5Gy0Ppbdu5qiVkDLdGI6ooQIsn9cJYrJs9xHUSg0sygyM9ZwAjP-pViNzN8DrOXrY8ZijtQfQtMJ9KD0an3wHCQHCYJP4WE2L-uYg-0sZ4ZNEtD9qRsAMiTA"/>
      <div class="absolute -bottom-6 -left-6 bg-surface p-6 rounded-DEFAULT shadow-xl border border-outline-variant/20 hidden md:block">
        <p class="font-headline-md text-on-surface">"La calidad nunca es un accidente."</p>
      </div>
    </div>
  </div>
</section>

<!-- CTA FINAL -->
<section class="py-20 px-gutter max-w-container-max mx-auto text-center">
  <h2 class="font-headline-lg text-headline-lg text-on-surface mb-4">¿Listo para transformar tu hogar?</h2>
  <p class="font-body-lg text-on-surface-variant max-w-xl mx-auto mb-8">Solicita una consulta gratuita y recibe una propuesta personalizada en menos de 24 horas.</p>
  <a href="/contacto" class="bg-primary-container text-on-primary-container px-8 py-4 rounded-DEFAULT font-label-caps text-label-caps hover:bg-primary hover:text-on-primary transition-colors inline-block">
    Solicitar Presupuesto Gratuito
  </a>
</section>`;
}

module.exports = { renderHome };
