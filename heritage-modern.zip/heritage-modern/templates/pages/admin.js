function renderAdminLogin(error) {
  return `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>Acceso administración · Heritage Modern</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=EB+Garamond:wght@500;600&family=Hanken+Grotesk:wght@400;500;600&display=swap" rel="stylesheet"/>
<style>body{font-family:'Hanken Grotesk',sans-serif;background:#fbf9f4;} h1{font-family:'EB Garamond',serif;}</style>
</head>
<body class="min-h-screen flex items-center justify-center px-4">
  <div class="w-full max-w-sm bg-white border border-[#d1c5b4] rounded p-8 shadow-sm">
    <h1 class="text-3xl mb-2 text-[#1b1c19]">Heritage Modern</h1>
    <p class="text-sm text-[#4e4639] mb-6">Panel de administración</p>
    ${error ? `<div class="bg-red-50 text-red-700 text-sm rounded px-4 py-3 mb-4">${error}</div>` : ""}
    <form method="POST" action="/admin/login" class="space-y-4">
      <div>
        <label class="block text-xs font-semibold uppercase tracking-wide text-[#4e4639] mb-2">Contraseña</label>
        <input type="password" name="password" required class="w-full border border-[#d1c5b4] rounded px-4 py-3 focus:outline-none focus:ring-1 focus:ring-[#775a19]" placeholder="••••••••"/>
      </div>
      <button type="submit" class="w-full bg-[#c5a059] text-[#4e3700] font-semibold rounded px-4 py-3 hover:bg-[#775a19] hover:text-white transition-colors">
        Entrar
      </button>
    </form>
    <a href="/" class="block text-center text-sm text-[#4e4639] mt-6 hover:underline">&larr; Volver al sitio</a>
  </div>
</body>
</html>`;
}

function renderAdminDashboard({ messages, projects }) {
  const rows = messages
    .slice()
    .reverse()
    .map(
      (m) => `
    <tr class="border-b border-[#e4e2dd]">
      <td class="px-4 py-3 text-sm text-[#4e4639] whitespace-nowrap">${new Date(m.receivedAt).toLocaleString("es-ES")}</td>
      <td class="px-4 py-3 text-sm font-medium text-[#1b1c19]">${escapeHtml(m.nombre)}</td>
      <td class="px-4 py-3 text-sm text-[#4e4639]">${escapeHtml(m.email)}</td>
      <td class="px-4 py-3 text-sm text-[#4e4639]">${escapeHtml(m.telefono || "—")}</td>
      <td class="px-4 py-3 text-sm text-[#4e4639]">${escapeHtml(m.tipo_reforma || "—")}</td>
      <td class="px-4 py-3 text-sm text-[#4e4639] max-w-xs">${escapeHtml(m.mensaje)}</td>
    </tr>`
    )
    .join("\n");

  const projectRows = projects
    .map(
      (p) => `
    <tr class="border-b border-[#e4e2dd]">
      <td class="px-4 py-3 text-sm font-medium text-[#1b1c19]">${escapeHtml(p.title)}</td>
      <td class="px-4 py-3 text-sm text-[#4e4639]">${escapeHtml(p.category)}</td>
      <td class="px-4 py-3 text-sm text-[#4e4639]">${escapeHtml(p.location)}</td>
      <td class="px-4 py-3 text-sm text-[#4e4639]">${p.year}</td>
    </tr>`
    )
    .join("\n");

  return `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>Panel de administración · Heritage Modern</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=EB+Garamond:wght@500;600&family=Hanken+Grotesk:wght@400;500;600&display=swap" rel="stylesheet"/>
<style>body{font-family:'Hanken Grotesk',sans-serif;background:#fbf9f4;} h1,h2{font-family:'EB Garamond',serif;}</style>
</head>
<body class="min-h-screen">
  <header class="bg-white border-b border-[#d1c5b4] px-6 py-4 flex justify-between items-center">
    <h1 class="text-2xl text-[#1b1c19]">Heritage Modern <span class="text-sm text-[#4e4639] font-sans">· Admin</span></h1>
    <div class="flex items-center gap-4">
      <a href="/" class="text-sm text-[#4e4639] hover:underline">Ver sitio</a>
      <form method="POST" action="/admin/logout"><button class="text-sm bg-[#e4e2dd] px-4 py-2 rounded hover:bg-[#d1c5b4]">Cerrar sesión</button></form>
    </div>
  </header>

  <main class="max-w-6xl mx-auto px-6 py-10 space-y-12">
    <section>
      <div class="flex items-center justify-between mb-4">
        <h2 class="text-2xl text-[#1b1c19]">Mensajes de contacto (${messages.length})</h2>
      </div>
      <div class="bg-white border border-[#d1c5b4] rounded overflow-x-auto">
        <table class="w-full text-left">
          <thead class="bg-[#f5f3ee]">
            <tr>
              <th class="px-4 py-3 text-xs font-semibold uppercase tracking-wide text-[#4e4639]">Fecha</th>
              <th class="px-4 py-3 text-xs font-semibold uppercase tracking-wide text-[#4e4639]">Nombre</th>
              <th class="px-4 py-3 text-xs font-semibold uppercase tracking-wide text-[#4e4639]">Email</th>
              <th class="px-4 py-3 text-xs font-semibold uppercase tracking-wide text-[#4e4639]">Teléfono</th>
              <th class="px-4 py-3 text-xs font-semibold uppercase tracking-wide text-[#4e4639]">Tipo</th>
              <th class="px-4 py-3 text-xs font-semibold uppercase tracking-wide text-[#4e4639]">Mensaje</th>
            </tr>
          </thead>
          <tbody>
            ${rows || `<tr><td colspan="6" class="px-4 py-8 text-center text-sm text-[#4e4639]">Aún no se han recibido mensajes.</td></tr>`}
          </tbody>
        </table>
      </div>
    </section>

    <section>
      <h2 class="text-2xl text-[#1b1c19] mb-4">Proyectos publicados (${projects.length})</h2>
      <div class="bg-white border border-[#d1c5b4] rounded overflow-x-auto">
        <table class="w-full text-left">
          <thead class="bg-[#f5f3ee]">
            <tr>
              <th class="px-4 py-3 text-xs font-semibold uppercase tracking-wide text-[#4e4639]">Título</th>
              <th class="px-4 py-3 text-xs font-semibold uppercase tracking-wide text-[#4e4639]">Categoría</th>
              <th class="px-4 py-3 text-xs font-semibold uppercase tracking-wide text-[#4e4639]">Ubicación</th>
              <th class="px-4 py-3 text-xs font-semibold uppercase tracking-wide text-[#4e4639]">Año</th>
            </tr>
          </thead>
          <tbody>${projectRows}</tbody>
        </table>
      </div>
      <p class="text-xs text-[#4e4639] mt-3">Para editar los proyectos, modifica el archivo <code class="bg-[#e4e2dd] px-1 rounded">data/projects.json</code>.</p>
    </section>
  </main>
</body>
</html>`;
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

module.exports = { renderAdminLogin, renderAdminDashboard };
