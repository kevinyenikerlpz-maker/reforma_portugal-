function renderContacto() {
  return `
<section class="pt-32 pb-24 bg-surface-container-low border-b border-outline-variant/20">
  <div class="max-w-container-max mx-auto px-gutter grid grid-cols-1 lg:grid-cols-2 gap-16">
    <div>
      <h1 class="font-display-lg text-display-lg text-on-surface mb-6">Empecemos tu proyecto</h1>
      <p class="font-body-lg text-on-surface-variant mb-8">Cuéntanos qué tienes en mente. Nuestro equipo se pondrá en contacto contigo en menos de 24 horas para programar una visita gratuita.</p>
      <div class="space-y-6 mb-12">
        <div class="flex items-start gap-4">
          <span class="material-symbols-outlined text-primary-container mt-1">location_on</span>
          <div><h4 class="font-label-caps text-on-surface mb-1">ÁREA DE SERVICIO</h4><p class="font-body-md text-on-surface-variant">Madrid Capital y Comunidad de Madrid (hasta 50km).</p></div>
        </div>
        <div class="flex items-start gap-4">
          <span class="material-symbols-outlined text-primary-container mt-1">mail</span>
          <div><h4 class="font-label-caps text-on-surface mb-1">EMAIL</h4><p class="font-body-md text-on-surface-variant">hola@heritagemodern.es</p></div>
        </div>
        <div class="flex items-start gap-4">
          <span class="material-symbols-outlined text-primary-container mt-1">call</span>
          <div><h4 class="font-label-caps text-on-surface mb-1">TELÉFONO</h4><p class="font-body-md text-on-surface-variant">+34 900 111 222</p></div>
        </div>
      </div>
    </div>
    <div class="bg-surface p-8 rounded-DEFAULT shadow-sm border border-outline-variant/30">
      <div id="form-message" class="hidden form-message rounded-DEFAULT px-4 py-3 mb-6 font-body-md text-sm"></div>
      <form id="contact-form" class="space-y-6">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label class="block font-label-caps text-on-surface-variant mb-2" for="nombre">Nombre completo</label>
            <input class="w-full bg-surface-container-low border-outline-variant/50 rounded focus:border-primary focus:ring-1 focus:ring-primary text-on-surface font-body-md px-4 py-3" id="nombre" name="nombre" placeholder="Ej. Ana García" type="text"/>
          </div>
          <div>
            <label class="block font-label-caps text-on-surface-variant mb-2" for="telefono">Teléfono</label>
            <input class="w-full bg-surface-container-low border-outline-variant/50 rounded focus:border-primary focus:ring-1 focus:ring-primary text-on-surface font-body-md px-4 py-3" id="telefono" name="telefono" placeholder="+34 600 000 000" type="tel"/>
          </div>
        </div>
        <div>
          <label class="block font-label-caps text-on-surface-variant mb-2" for="email">Email</label>
          <input class="w-full bg-surface-container-low border-outline-variant/50 rounded focus:border-primary focus:ring-1 focus:ring-primary text-on-surface font-body-md px-4 py-3" id="email" name="email" placeholder="ana@email.com" type="email"/>
        </div>
        <div>
          <label class="block font-label-caps text-on-surface-variant mb-2" for="tipo_reforma">Tipo de reforma</label>
          <select class="w-full bg-surface-container-low border-outline-variant/50 rounded focus:border-primary focus:ring-1 focus:ring-primary text-on-surface font-body-md px-4 py-3" id="tipo_reforma" name="tipo_reforma">
            <option>Reforma Integral</option>
            <option>Reforma de Cocina</option>
            <option>Reforma de Baños</option>
            <option>Otro</option>
          </select>
        </div>
        <div>
          <label class="block font-label-caps text-on-surface-variant mb-2" for="mensaje">Breve descripción del proyecto</label>
          <textarea class="w-full bg-surface-container-low border-outline-variant/50 rounded focus:border-primary focus:ring-1 focus:ring-primary text-on-surface font-body-md px-4 py-3" id="mensaje" name="mensaje" placeholder="Cuéntanos un poco sobre tu vivienda y qué te gustaría conseguir..." rows="4"></textarea>
        </div>
        <button id="form-submit-btn" class="w-full bg-primary-container text-on-primary-container px-8 py-4 rounded-DEFAULT font-label-caps text-label-caps hover:bg-primary hover:text-on-primary transition-colors text-center" type="submit">
          Solicitar mi presupuesto gratuito
        </button>
      </form>
    </div>
  </div>
</section>

<section class="py-24 px-gutter max-w-3xl mx-auto" id="faq">
  <div class="text-center mb-16">
    <h2 class="font-headline-lg text-headline-lg text-on-surface mb-4">Preguntas Frecuentes</h2>
    <p class="font-body-lg text-on-surface-variant">Resolvemos las dudas más comunes sobre nuestro proceso de reforma.</p>
  </div>
  <div class="space-y-4">
    <details class="group bg-surface-container-low rounded-DEFAULT border border-outline-variant/30">
      <summary class="flex justify-between items-center font-headline-md text-lg p-6 cursor-pointer text-on-surface list-none">
        ¿Cuánto dura una reforma integral?
        <span class="material-symbols-outlined transition-transform group-open:rotate-180">expand_more</span>
      </summary>
      <div class="px-6 pb-6 pt-0 font-body-md text-on-surface-variant">El tiempo estimado varía según la complejidad y tamaño de la vivienda. Una reforma integral estándar (80-100m²) suele durar entre 3 y 4 meses desde el inicio de la demolición.</div>
    </details>
    <details class="group bg-surface-container-low rounded-DEFAULT border border-outline-variant/30">
      <summary class="flex justify-between items-center font-headline-md text-lg p-6 cursor-pointer text-on-surface list-none">
        ¿Se encargan de tramitar los permisos?
        <span class="material-symbols-outlined transition-transform group-open:rotate-180">expand_more</span>
      </summary>
      <div class="px-6 pb-6 pt-0 font-body-md text-on-surface-variant">Sí, gestionamos todas las licencias de obra necesarias con el ayuntamiento y la comunicación con la comunidad de vecinos para que no tengas que preocuparte de nada.</div>
    </details>
    <details class="group bg-surface-container-low rounded-DEFAULT border border-outline-variant/30">
      <summary class="flex justify-between items-center font-headline-md text-lg p-6 cursor-pointer text-on-surface list-none">
        ¿Qué incluye la garantía de 5 años?
        <span class="material-symbols-outlined transition-transform group-open:rotate-180">expand_more</span>
      </summary>
      <div class="px-6 pb-6 pt-0 font-body-md text-on-surface-variant">Nuestra garantía cubre cualquier vicio oculto o defecto de ejecución en instalaciones (fontanería, electricidad), albañilería y acabados realizados por nuestro equipo.</div>
    </details>
    <details class="group bg-surface-container-low rounded-DEFAULT border border-outline-variant/30">
      <summary class="flex justify-between items-center font-headline-md text-lg p-6 cursor-pointer text-on-surface list-none">
        ¿Ofrecen opciones de financiación?
        <span class="material-symbols-outlined transition-transform group-open:rotate-180">expand_more</span>
      </summary>
      <div class="px-6 pb-6 pt-0 font-body-md text-on-surface-variant">Trabajamos con varias entidades financieras para ofrecer planes de pago fraccionado hasta en 48 meses con condiciones muy competitivas.</div>
    </details>
    <details class="group bg-surface-container-low rounded-DEFAULT border border-outline-variant/30">
      <summary class="flex justify-between items-center font-headline-md text-lg p-6 cursor-pointer text-on-surface list-none">
        ¿Cómo se calcula el presupuesto inicial?
        <span class="material-symbols-outlined transition-transform group-open:rotate-180">expand_more</span>
      </summary>
      <div class="px-6 pb-6 pt-0 font-body-md text-on-surface-variant">Elaboramos mediciones detalladas in situ y valoramos cada partida (demolición, albañilería, instalaciones, revestimientos) basándonos en las calidades elegidas durante la fase de diseño. Es un presupuesto cerrado sin sorpresas.</div>
    </details>
  </div>
</section>`;
}

module.exports = { renderContacto };
