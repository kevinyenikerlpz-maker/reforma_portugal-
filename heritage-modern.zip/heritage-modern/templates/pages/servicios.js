function renderServicios(services) {
  const cards = services
    .map(
      (s, i) => `
    <div class="grid grid-cols-1 md:grid-cols-2 gap-10 items-center py-16 ${
        i !== services.length - 1 ? "border-b border-outline-variant/20" : ""
      }" id="${s.id}">
      <div class="${i % 2 === 1 ? "order-1 md:order-2" : "order-1"}">
        <span class="material-symbols-outlined text-primary-container text-5xl mb-6 block">${s.icon}</span>
        <h2 class="font-headline-lg text-headline-md text-on-surface mb-4">${s.title}</h2>
        <p class="font-body-lg text-on-surface-variant mb-6">${s.summary}</p>
        <ul class="space-y-3">
          ${s.details
            .map(
              (d) => `<li class="flex items-start gap-3 font-body-md text-on-surface-variant">
              <span class="material-symbols-outlined text-primary text-xl mt-0.5">check_circle</span>${d}
            </li>`
            )
            .join("\n")}
        </ul>
        <a href="/contacto" class="mt-8 inline-block bg-primary-container text-on-primary-container px-6 py-3 rounded-DEFAULT font-label-caps text-label-caps hover:bg-primary hover:text-on-primary transition-colors">
          Pedir presupuesto para este servicio
        </a>
      </div>
      <div class="bg-surface-container-low border border-outline-variant/30 rounded-DEFAULT aspect-video flex items-center justify-center ${
        i % 2 === 1 ? "order-2 md:order-1" : "order-2"
      }">
        <span class="material-symbols-outlined text-primary-container text-8xl opacity-40">${s.icon}</span>
      </div>
    </div>`
    )
    .join("\n");

  return `
<section class="pt-32 pb-16 px-gutter max-w-container-max mx-auto text-center">
  <h1 class="font-display-lg text-display-lg text-on-surface mb-6">Nuestros Servicios</h1>
  <p class="font-body-lg text-on-surface-variant max-w-2xl mx-auto">Especialistas en transformar espacios con materiales de primera calidad y acabados impecables, de principio a fin.</p>
</section>

<section class="px-gutter max-w-container-max mx-auto pb-16">
  ${cards}
</section>

<section class="py-20 px-gutter max-w-container-max mx-auto text-center bg-surface-container-low border-t border-outline-variant/20">
  <h2 class="font-headline-lg text-headline-lg text-on-surface mb-4">¿No sabes qué servicio necesitas?</h2>
  <p class="font-body-lg text-on-surface-variant max-w-xl mx-auto mb-8">Cuéntanos tu proyecto y te asesoramos sin compromiso sobre la mejor solución para tu hogar.</p>
  <a href="/contacto" class="bg-primary-container text-on-primary-container px-8 py-4 rounded-DEFAULT font-label-caps text-label-caps hover:bg-primary hover:text-on-primary transition-colors inline-block">
    Hablar con un especialista
  </a>
</section>`;
}

module.exports = { renderServicios };
