function renderProyectos(projects) {
  const categories = ["todos", ...new Set(projects.map((p) => p.category))];

  const filterButtons = categories
    .map(
      (c) =>
        `<button class="filter-btn ${
          c === "todos" ? "active" : ""
        } px-5 py-2 rounded-full border border-outline-variant/40 font-label-caps text-label-caps text-on-surface-variant transition-colors" data-filter="${c}">${c}</button>`
    )
    .join("\n");

  const cards = projects
    .map(
      (p) => `
    <div id="${p.id}" data-category="${p.category}" class="bg-surface-container-low rounded-DEFAULT overflow-hidden border border-outline-variant/30 scroll-mt-28">
      <div class="aspect-[4/3] overflow-hidden">
        <img alt="${p.title}" class="w-full h-full object-cover" src="${p.image}"/>
      </div>
      <div class="p-6">
        <span class="inline-block bg-primary-container/20 text-primary px-2 py-1 rounded text-xs font-label-caps mb-3">${p.category}</span>
        <h3 class="font-headline-md text-xl text-on-surface mb-2">${p.title}</h3>
        <p class="font-body-md text-on-surface-variant mb-4">${p.description}</p>
        <div class="grid grid-cols-3 gap-2 text-sm border-t border-outline-variant/20 pt-4">
          <div><p class="text-on-surface-variant text-xs font-label-caps">UBICACIÓN</p><p class="text-on-surface">${p.location}</p></div>
          <div><p class="text-on-surface-variant text-xs font-label-caps">SUPERFICIE</p><p class="text-on-surface">${p.area}</p></div>
          <div><p class="text-on-surface-variant text-xs font-label-caps">DURACIÓN</p><p class="text-on-surface">${p.duration}</p></div>
        </div>
      </div>
    </div>`
    )
    .join("\n");

  return `
<section class="pt-32 pb-16 px-gutter max-w-container-max mx-auto text-center">
  <h1 class="font-display-lg text-display-lg text-on-surface mb-6">Proyectos</h1>
  <p class="font-body-lg text-on-surface-variant max-w-2xl mx-auto mb-10">Explora nuestra selección de reformas y encuentra inspiración para tu próximo proyecto.</p>
  <div class="flex flex-wrap justify-center gap-3">
    ${filterButtons}
  </div>
</section>

<section class="px-gutter max-w-container-max mx-auto pb-24">
  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
    ${cards}
  </div>
</section>

<section class="py-20 px-gutter max-w-container-max mx-auto text-center bg-surface-container-low border-t border-outline-variant/20">
  <h2 class="font-headline-lg text-headline-lg text-on-surface mb-4">¿Te gusta lo que ves?</h2>
  <p class="font-body-lg text-on-surface-variant max-w-xl mx-auto mb-8">Hablemos de tu proyecto y creemos juntos tu próxima transformación.</p>
  <a href="/contacto" class="bg-primary-container text-on-primary-container px-8 py-4 rounded-DEFAULT font-label-caps text-label-caps hover:bg-primary hover:text-on-primary transition-colors inline-block">
    Solicitar Presupuesto
  </a>
</section>`;
}

module.exports = { renderProyectos };
