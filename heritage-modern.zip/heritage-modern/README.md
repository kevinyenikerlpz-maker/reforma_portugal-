# Heritage Modern — Sitio web + backend

Sitio multipágina (Inicio, Servicios, Proyectos, Contacto) con un backend en
Node.js puro (sin dependencias externas) que guarda los mensajes del
formulario de contacto y expone un panel de administración en `/admin`.

## Estructura

```
app.js              → toda la lógica de rutas (compartida entre local y Vercel)
server.js           → arranque local: node server.js
api/index.js         → punto de entrada para Vercel (función serverless)
vercel.json          → configuración de despliegue en Vercel
templates/           → HTML generado (layout, home, servicios, proyectos, contacto, admin)
lib/store.js          → guarda/lee mensajes de contacto (data/messages.json)
lib/auth.js            → login del panel de admin (usa variables de entorno en producción)
data/projects.json      → proyectos mostrados en /proyectos
data/services.json       → servicios mostrados en /servicios
css/, js/                → estáticos servidos en la raíz (/css/style.css, /js/main.js)
```

## Probar en local

No hace falta instalar nada (`npm install` no es necesario, cero dependencias):

```bash
node server.js
```

Abre `http://localhost:3000`. Panel de admin en `http://localhost:3000/admin`
con la contraseña por defecto `cambia-esta-clave` (cámbiala, ver abajo).

---

## 1. Subir el código a tu repositorio de GitHub

Tu repo: `https://github.com/kevinyenikerlpz-maker/reforma_portugal-.git`

Desde **tu propio ordenador** (yo no tengo acceso a internet desde aquí, así
que estos comandos los ejecutas tú), dentro de la carpeta del proyecto:

```bash
cd heritage-modern
git init
git remote add origin https://github.com/kevinyenikerlpz-maker/reforma_portugal-.git
git add .
git commit -m "Sitio Heritage Modern: multi-página + backend"
git branch -M main
git push -u origin main
```

Si el repo de GitHub ya tiene contenido (README inicial, etc.) y el push falla
por historiales distintos, usa:

```bash
git push -u origin main --force
```

(solo si estás seguro de que quieres sobrescribir lo que haya en el repo).

---

## 2. Desplegar en Vercel

1. Entra en https://vercel.com y pulsa **Add New → Project**.
2. Elige **Import Git Repository** y selecciona
   `kevinyenikerlpz-maker/reforma_portugal-`.
3. Framework Preset: déjalo en **Other** (no hace falta build command ni
   output directory, el proyecto no tiene paso de compilación).
4. **Antes de darle a Deploy**, abre "Environment Variables" y añade:
   - `ADMIN_PASSWORD` → la contraseña que quieras usar para `/admin`
   - `SESSION_SECRET` → una cadena larga y aleatoria (por ejemplo, genera una
     con `openssl rand -hex 32` en tu terminal)
5. Pulsa **Deploy**. En 1-2 minutos tendrás tu URL en `https://tu-proyecto.vercel.app`.

### Persistencia de mensajes: Vercel KV (ya integrado)

Las funciones serverless de Vercel tienen el disco de solo lectura, así que
`lib/store.js` detecta automáticamente si el proyecto tiene una base de
datos **Vercel KV** conectada y, si es así, guarda ahí los mensajes en vez
de en un archivo (que no persistiría). Si no hay KV conectado, sigue usando
el archivo local (útil solo para desarrollo).

**Para activarlo, después de importar el proyecto en Vercel:**

1. En el panel de tu proyecto en Vercel, ve a la pestaña **Storage**.
2. Pulsa **Create Database** → elige **KV** → dale un nombre (p. ej. `heritage-modern-kv`) → **Create**.
3. En el siguiente paso, pulsa **Connect to Project** y selecciona tu proyecto — esto añade automáticamente las variables `KV_REST_API_URL`, `KV_REST_API_TOKEN`, etc. a tu proyecto.
4. Vuelve a **Deployments** y haz **Redeploy** del último despliegue (para que tome las nuevas variables de entorno).

A partir de ahí, cada mensaje del formulario de contacto se guardará de
forma permanente y aparecerá en `/admin`. La capa gratuita de Vercel KV es
de sobra para el volumen de un formulario de contacto.

Si en algún momento prefieres no usar Vercel KV, la alternativa es
desplegar en un servicio con servidor persistente (Render, Railway, un VPS)
— ahí el sistema de archivos local funciona tal cual, sin tocar nada.

---

## Cambiar la contraseña de administración

- **En local**: la primera vez que arrancas el servidor se crea
  `data/config.json` con la contraseña `cambia-esta-clave`. Bórralo y define
  la variable de entorno `ADMIN_PASSWORD` antes de arrancar, por ejemplo:
  `ADMIN_PASSWORD=mi-clave-segura node server.js`
- **En Vercel**: se controla enteramente con la variable de entorno
  `ADMIN_PASSWORD` (paso 4 de arriba).

## Editar proyectos y servicios

Los proyectos que aparecen en la home y en `/proyectos` están en
`data/projects.json`, y los servicios de `/servicios` en
`data/services.json`. Edita esos archivos y vuelve a desplegar (o recarga en
local) para ver los cambios — no hace falta tocar código.
